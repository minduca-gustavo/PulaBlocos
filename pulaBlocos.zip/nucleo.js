async function navegar(url, opcoes = {}) {
    const { novaAba = true } = opcoes
    if (novaAba) {
        return await chrome.tabs.create({ url })
    }
    const [abaAtiva] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (abaAtiva) return await chrome.tabs.update(abaAtiva.id, { url })
    return await chrome.tabs.create({ url })
}